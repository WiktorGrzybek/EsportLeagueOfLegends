﻿using Microsoft.EntityFrameworkCore;
using System;

namespace LoLGui.Models
{
    // 1) get_all_tournaments
    [Keyless]
    public class GetAllTournamentsResult
    {
        public int TurniejID { get; set; }
        public string NazwaTurnieju { get; set; }
        public string Rodzaj { get; set; }
        public string Organizator { get; set; }
        public string Adres { get; set; }
        public DateTime Data { get; set; }
    }

    // 2) get_team_players_stats
    [Keyless]
    public class GetTeamPlayersStatsResult
    {
        public int GraczID { get; set; }
        public string Nickname { get; set; }
        public int Przegrane { get; set; }
        public int Wygrane { get; set; }
        public int Eliminacje { get; set; }
        public int Asysty { get; set; }
        public int Zgony { get; set; }
    }

    // 3) get_recent_matches_by_commentator
    [Keyless]
    public class GetRecentMatchesByCommentatorResult
    {
        public int MeczID { get; set; }
        public int komentatorid { get; set; }
        public int TurniejID { get; set; }
    }

    // 4) get_teams_by_region
    [Keyless]
    public class GetTeamsByRegionResult
    {
        public int druzynaid { get; set; }
        public string Nazwa { get; set; }
    }

    // 5) get_all_coaches
    [Keyless]
    public class GetAllCoachesResult
    {
        public int TrenerID { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public int druzynaid { get; set; }
    }

    // 6) get_top_kda_players
    [Keyless]
    public class GetTopKdaPlayersResult
    {
        public int GraczID { get; set; }
        public string Nickname { get; set; }
        public decimal KDA { get; set; }
    }

    // 7) get_most_picked_character
    [Keyless]
    public class GetMostPickedCharacterResult
    {
        public int PostacID { get; set; }
        public string Nazwa { get; set; }
        public int LiczbaWybor { get; set; }
    }

    // 8) get_best_team_in_tournament
    [Keyless]
    public class GetBestTeamInTournamentResult
    {
        public int druzynaid { get; set; }
        public string nazwa { get; set; }
        public int liczbawygranych { get; set; }
    }

    // 9) get_players_with_teams
    [Keyless]
    public class GetPlayersWithTeamsResult
    {
        public int GraczID { get; set; }
        public string Nickname { get; set; }
        public int druzynaid { get; set; }
        public string DruzynaNazwa { get; set; }
    }

    // 10) get_matches_by_tournament
    [Keyless]
    public class GetMatchesByTournamentResult
    {
        public int MeczID { get; set; }
        public int komentatorid { get; set; }
        public int TurniejID { get; set; }
    }

    // 11) get_top_winners
    [Keyless]
    public class GetTopWinnersResult
    {
        public int GraczID { get; set; }
        public string Nickname { get; set; }
        public int Wygrane { get; set; }
    }

    // 12) get_teams_with_most_players
    [Keyless]
    public class GetTeamsWithMostPlayersResult
    {
        public int  druzynaid { get; set; }
        public string DruzynaNazwa { get; set; }
        public int LiczbaGraczy { get; set; }
    }

    // 13) get_tournaments_count_by_region
    [Keyless]
    public class GetTournamentsCountByRegionResult
    {
        public int RegionID { get; set; }
        public string RegionNazwa { get; set; }
        public int LiczbaTurniejow { get; set; }
    }

    // 14) get_coaches_by_region
    [Keyless]
    public class GetCoachesByRegionResult
    {
        public int TrenerID { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public string DruzynaNazwa { get; set; }
    }

    // 15) get_match_count_by_commentator
    [Keyless]
    public class GetMatchCountByCommentatorResult
    {
        public int komentatorid { get; set; }
        public string imie { get; set; }
        public string nazwisko { get; set; }
        public string nickname { get; set; }
        public int liczbameczow { get; set; }
    }


    // 17) get_average_kills_and_deaths_by_player
    [Keyless]
    public class GetAverageKillsAndDeathsByPlayerResult
    {
        public int GraczID { get; set; }
        public string Nickname { get; set; }
        public decimal SredniaEliminacji { get; set; }
        public decimal SredniaZgonow { get; set; }
    }

    // 18) get_top_assisters_by_team
    [Keyless]
    public class GetTopAssistersByTeamResult
    {
        public int GraczID { get; set; }
        public string Nickname { get; set; }
        public int Asysty { get; set; }
    }

    // 19) get_commentators_by_region
    [Keyless]
    public class GetCommentatorsByRegionResult
    {
        public int komentatorid { get; set; }
        public string imie { get; set; }
        public string nazwisko { get; set; }
        public string nickname { get; set; }
    }

    // 20) get_most_picked_characters
    [Keyless]
    public class GetMostPickedCharactersResult
    {
        public int PostacID { get; set; }
        public string Nazwa { get; set; }
        public int LiczbaWybran { get; set; }
    }

    // 21) get_teams_with_most_transfers
    [Keyless]
    public class GetTeamsWithMostTransfersResult
    {
        public int druzynaid { get; set; }
        public string Nazwa { get; set; }
        public int LiczbaTransferow { get; set; }
    }
    [Keyless]
    public class GetTeamWinsResult
    {
        public int TeamWins { get; set; }
    }

    [Keyless]
    public class GetAllTeamsResult
    {
        public int DruzynaID { get; set; }
        public string Nazwa { get; set; }
        public int RegionID { get; set; }
    }

    [Keyless]
    public class GetAllRegionsResult
    {
        public int RegionID { get; set; }
        public string Nazwa { get; set; }
        public string Skrot { get; set; }
    }

    [Keyless]
    public class GetAllPlayersResult
    {
        public int GraczID { get; set; }
        public string Nickname { get; set; }
        public int DruzynaID { get; set; }
        public int Przegrane { get; set; }
        public int Wygrane { get; set; }
        public int Eliminacje { get; set; }
        public int Asysty { get; set; }
        public int Zgony { get; set; }
        public string Pozycja { get; set; }
    }

    [Keyless]
    public class XYZ
    {
        public int GraczID { get; set; }
        public int MeczID { get; set; }
        public int PostacID { get; set; }
        public int wynik { get; set; }
    }


    [Keyless]
    public class GetAllMatchesResult
    {
        public int MeczID { get; set; }
        public int KomentatorID { get; set; }
        public int TurniejID { get; set; }
    }
    public class GetAllMatchesResultFront
    {
        public int MeczID { get; set; }
        public string DruzynaNames { get; set; }
        public string GraczeNames { get; set; }
        public int KomentatorID { get; set; }
        public int TurniejID { get; set; }
    }
    
    [Keyless]
    public class GetAllCharactersResult
    {
        public int PostacID { get; set; }
        public string Nazwa { get; set; }
    }

    [Keyless]
    public class GetAllTransfersResult
    {
        public int TransferID { get; set; }
        public int GraczID { get; set; }
        public int Druzyna1 { get; set; }
        public int Druzyna2 { get; set; }
    }

    public class GetAllTransfersResultFront
    {
        public int TransferID { get; set; }
        public int GraczID { get; set; }
        public string GraczName { get; set; }
        public int Druzyna1 { get; set; }
        public int Druzyna2 { get; set; }
    }


    [Keyless]
    public class GetAllCommentatorsResult
    {
        public int KomentatorID { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public string Nickname { get; set; }
    }
}
