﻿using LoLGui.Models;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using NpgsqlTypes;
using System;
using System.Threading.Tasks;

namespace LoLGui
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }



        // 1. Dodaj drużynę
        public async Task DodajDruzyneAsync(string nazwa, int regionId)
        {
            var pNazwa = new NpgsqlParameter("@p_nazwa", nazwa);
            var pRegionId = new NpgsqlParameter("@p_regionid", regionId);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.dodajdruzyne(@p_nazwa, @p_regionid)",
                pNazwa, pRegionId
            );
        }

        // 2. Dodaj gracza
        public async Task DodajGraczaAsync(string nickname, int druzynaId, string pozycja)
        {
            var pNickname = new NpgsqlParameter("@p_nickname", NpgsqlTypes.NpgsqlDbType.Varchar)
            {
                Value = (object)nickname ?? DBNull.Value
            };
            var pDruzynaId = new NpgsqlParameter("@p_druzynaid", druzynaId);
            var pPozycja = new NpgsqlParameter("@p_pozycja", NpgsqlTypes.NpgsqlDbType.Varchar)
            {
                Value = (object)pozycja ?? DBNull.Value
            };


            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.dodajgracza(@p_nickname, @p_druzynaid, @p_pozycja)",
                pNickname, pDruzynaId, pPozycja
            );
        }

        // 3. Dodaj mecz
        public async Task DodajMeczAsync(int komentatorId, int turniejId)
        {
            var pKomentatorId = new NpgsqlParameter("@p_komentatorid", komentatorId);
            var pTurniejId = new NpgsqlParameter("@p_turniejid", turniejId);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.dodajmecz(@p_komentatorid, @p_turniejid)",
                pKomentatorId, pTurniejId
            );
        }

        // 4. Dodaj postać
        public async Task DodajPostacAsync(string nazwa)
        {
            var pNazwa = new NpgsqlParameter("@p_nazwa", nazwa);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.dodajpostac(@p_nazwa)",
                pNazwa
            );
        }

        // 5. Dodaj region
        public async Task DodajRegionAsync(string nazwa, string skrot)
        {
            var pNazwa = new NpgsqlParameter("@p_nazwa", nazwa);
            var pSkrot = new NpgsqlParameter("@p_skrot", skrot);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.dodajregion(@p_nazwa, @p_skrot)",
                pNazwa, pSkrot
            );
        }

        // 6. Dodaj transfer
        public async Task DodajTransferAsync(int graczId, int druzyna1, int druzyna2)
        {
            var pGraczId = new NpgsqlParameter("@p_graczid", graczId);
            var pDruzyna1 = new NpgsqlParameter("@p_druzyna1", druzyna1);
            var pDruzyna2 = new NpgsqlParameter("@p_druzyna2", druzyna2);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.dodajtransfer(@p_graczid, @p_druzyna1, @p_druzyna2)",
                pGraczId, pDruzyna1, pDruzyna2
            );
        }

        // 7. Dodaj trenera
        public async Task DodajTreneraAsync(string imie, string nazwisko, int druzynaId)
        {
            var pImie = new NpgsqlParameter("@p_imie", imie);
            var pNazwisko = new NpgsqlParameter("@p_nazwisko", nazwisko);
            var pDruzynaId = new NpgsqlParameter("@p_druzynaid", druzynaId);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.dodajtrenera(@p_imie, @p_nazwisko, @p_druzynaid)",
                pImie, pNazwisko, pDruzynaId
            );
        }

        // 8. Dodaj turniej
        public async Task DodajTurniejAsync(
            string nazwaTurnieju,
            string rodzaj,
            string organizator,
            string adres,
            int regionId,
            DateTime data
        )
        {
            var pNazwaTurnieju = new NpgsqlParameter("@p_nazwaturnieju", nazwaTurnieju);
            var pRodzaj = new NpgsqlParameter("@p_rodzaj", rodzaj);
            var pOrganizator = new NpgsqlParameter("@p_organizator", organizator);
            var pAdres = new NpgsqlParameter("@p_adres", adres);
            var pRegionId = new NpgsqlParameter("@p_regionid", regionId);
            var pData = new NpgsqlParameter("@p_data", data);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.dodajturniej(@p_nazwaturnieju, @p_rodzaj, @p_organizator, @p_adres, @p_regionid, @p_data)",
                pNazwaTurnieju, pRodzaj, pOrganizator, pAdres, pRegionId, pData
            );
        }

        //// 21. Dodaj xyz
        //public async Task DodajXyzAsync(int graczId, int meczId, int postacId, int wynik)
        //{
        //    var pGraczId = new NpgsqlParameter("@p_graczid", graczId);
        //    var pMeczId = new NpgsqlParameter("@p_meczid", meczId);
        //    var pPostacId = new NpgsqlParameter("@p_postacid", postacId);
        //    var pWynik = new NpgsqlParameter("@p_wynik", wynik);

        //    await Database.ExecuteSqlRawAsync(
        //        "CALL esportleagueoflegends.dodajxyz(@p_graczid, @p_meczid, @p_postacid, @p_wynik)",
        //        pGraczId, pMeczId, pPostacId, pWynik
        //    );
        //}



        // 9. Edytuj drużynę
        public async Task EdytujDruzyneAsync(int druzynaId, string nazwa, int regionId)
        {
            var pDruzynaId = new NpgsqlParameter("@p_druzynaid", druzynaId);
            var pNazwa = new NpgsqlParameter("@p_nazwa", nazwa);
            var pRegionId = new NpgsqlParameter("@p_regionid", regionId);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.edytujdruzyne(@p_druzynaid, @p_nazwa, @p_regionid)",
                pDruzynaId, pNazwa, pRegionId
            );
        }

        // 10. Edytuj gracza
        public async Task EdytujGraczaAsync(int graczId, string nickname, int druzynaId, string pozycja, int przegrane, int wygrane, int eliminacje, int asysty, int zgony)
        {
            var pGraczId = new NpgsqlParameter("@p_graczid", graczId);
            var pNickname = new NpgsqlParameter("@p_nickname", nickname);
            var pDruzynaId = new NpgsqlParameter("@p_druzynaid", druzynaId);
            var pPozycja = new NpgsqlParameter("@p_pozycja", pozycja);
            var pPrzegrane = new NpgsqlParameter("@p_przegrane", przegrane);
            var pWygrane = new NpgsqlParameter("@p_wygrane", wygrane);
            var pEliminacje = new NpgsqlParameter("@p_eliminacje", eliminacje);
            var pAsysty = new NpgsqlParameter("@p_asysty", asysty);
            var pZgony = new NpgsqlParameter("@p_zgony", zgony);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.edytujgracza(@p_graczid, @p_nickname, @p_druzynaid, @p_pozycja, @p_przegrane, @p_wygrane, @p_eliminacje, @p_asysty, @p_zgony)",
                pGraczId, pNickname, pDruzynaId, pPozycja, pPrzegrane, pWygrane, pEliminacje, pAsysty, pZgony
            );
        }

        // 11. Edytuj mecz
        public async Task EdytujMeczAsync(int meczId, int komentatorId, int turniejId)
        {
            var pMeczId = new NpgsqlParameter("@p_meczid", meczId);
            var pKomentatorId = new NpgsqlParameter("@p_komentatorid", komentatorId);
            var pTurniejId = new NpgsqlParameter("@p_turniejid", turniejId);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.edytujmecz(@p_meczid, @p_komentatorid, @p_turniejid)",
                pMeczId, pKomentatorId, pTurniejId
            );
        }

        // 12. Edytuj postać
        public async Task EdytujPostacAsync(int postacId, string nazwa)
        {
            var pPostacId = new NpgsqlParameter("@p_postacid", postacId);
            var pNazwa = new NpgsqlParameter("@p_nazwa", nazwa);
            

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.edytujpostac(@p_postacid, @p_nazwa)",
                pPostacId, pNazwa
            );
        }

        // 13. Edytuj region
        public async Task EdytujRegionAsync(int regionId, string nazwa, string skrot)
        {
            var pRegionId = new NpgsqlParameter("@p_regionid", regionId);
            var pNazwa = new NpgsqlParameter("@p_nazwa", nazwa);
            var pSkrot = new NpgsqlParameter("@p_skrot", skrot);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.edytujregion(@p_regionid, @p_nazwa, @p_skrot)",
                pRegionId, pNazwa, pSkrot
            );
        }

        // 14. Edytuj transfer
        public async Task EdytujTransferAsync(int transferId, int graczId, int druzyna1, int druzyna2)
        {
            var pTransferId = new NpgsqlParameter("@p_transferid", transferId);
            var pGraczId = new NpgsqlParameter("@p_graczid", graczId);
            var pDruzyna1 = new NpgsqlParameter("@p_druzyna1", druzyna1);
            var pDruzyna2 = new NpgsqlParameter("@p_druzyna2", druzyna2);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.edytujtransfer(@p_transferid, @p_graczid, @p_druzyna1, @p_druzyna2)",
                pTransferId, pGraczId, pDruzyna1, pDruzyna2
            );
        }

        // 15. Edytuj trenera
        public async Task EdytujTreneraAsync(int trenerId, string imie, string nazwisko, int druzynaId)
        {
            var pTrenerId = new NpgsqlParameter("@p_trenerid", trenerId);
            var pImie = new NpgsqlParameter("@p_imie", imie);
            var pNazwisko = new NpgsqlParameter("@p_nazwisko", nazwisko);
            var pDruzynaId = new NpgsqlParameter("@p_druzynaid", druzynaId);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.edytujtrenera(@p_trenerid, @p_imie, @p_nazwisko, @p_druzynaid)",
                pTrenerId, pImie, pNazwisko, pDruzynaId
            );
        }

        // 16. Edytuj turniej
        public async Task EdytujTurniejAsync(
            int turniejId,
            string nazwaTurnieju,
            string rodzaj,
            string organizator,
            string adres,
            int regionId,
            DateTime data
        )
        {
            var pTurniejId = new NpgsqlParameter("@p_turniejid", turniejId);
            var pNazwaTurnieju = new NpgsqlParameter("@p_nazwaturnieju", nazwaTurnieju);
            var pRodzaj = new NpgsqlParameter("@p_rodzaj", rodzaj);
            var pOrganizator = new NpgsqlParameter("@p_organizator", organizator);
            var pAdres = new NpgsqlParameter("@p_adres", adres);
            var pRegionId = new NpgsqlParameter("@p_regionid", regionId);
            var pData = new NpgsqlParameter("@p_data", data);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.edytujturniej(@p_turniejid, @p_nazwaturnieju, @p_rodzaj, @p_organizator, @p_adres, @p_regionid, @p_data)",
                pTurniejId, pNazwaTurnieju, pRodzaj, pOrganizator, pAdres, pRegionId, pData
            );
        }

        //// 22. Edytuj xyz
        //public async Task EdytujXyzAsync(int uniqueId, int graczId, int meczId, int postacId, int wynik)
        //{
        //    var pUniqueId = new NpgsqlParameter("@p_uniqueid", uniqueId);
        //    var pGraczId = new NpgsqlParameter("@p_graczid", graczId);
        //    var pMeczId = new NpgsqlParameter("@p_meczid", meczId);
        //    var pPostacId = new NpgsqlParameter("@p_postacid", postacId);
        //    var pWynik = new NpgsqlParameter("@p_wynik", wynik);

        //    await Database.ExecuteSqlRawAsync(
        //        "CALL esportleagueoflegends.edytujxyz(@p_uniqueid, @p_graczid, @p_meczid, @p_postacid, @p_wynik)",
        //        pUniqueId, pGraczId, pMeczId, pPostacId, pWynik
        //    );
        //}


        // 17. Usuń drużynę
        public async Task UsunDruzyneAsync(int druzynaId)
        {
            var pDruzynaId = new NpgsqlParameter("@p_druzynaid", druzynaId);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.usundruzyne(@p_druzynaid)",
                pDruzynaId
            );
        }

        // 18. Usuń gracza
        public async Task UsunGraczaAsync(int graczId)
        {
            var pGraczId = new NpgsqlParameter("@p_graczid", graczId);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.usungracza(@p_graczid)",
                pGraczId
            );
        }

        // 19. Usuń region
        public async Task UsunRegionAsync(int regionId)
        {
            var pRegionId = new NpgsqlParameter("@p_regionid", regionId);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.usunregion(@p_regionid)",
                pRegionId
            );
        }

        // 20. Usuń trenera
        public async Task UsunTreneraAsync(int trenerId)
        {
            var pTrenerId = new NpgsqlParameter("@p_trenerid", trenerId);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.usuntrenera(@p_trenerid)",
                pTrenerId
            );
        }
        // 21.Dodaj komentatora
        public async Task DodajKomentatoraAsync(string imie, string nazwisko, string nickname)
        {
            var pImie = new NpgsqlParameter("@p_imie", imie);
            var pNazwisko = new NpgsqlParameter("@p_nazwisko", nazwisko);
            var pNickname = new NpgsqlParameter("@p_nickname", nickname);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.dodajkomentatora(@p_imie, @p_nazwisko, @p_nickname)",
                pImie, pNazwisko, pNickname
            );
        }
        // 22.Edytuj komentatora
        public async Task EdytujKomentatoraAsync(int komentatorId, string imie, string nazwisko, string nickname)
        {
            var pKomentatorId = new NpgsqlParameter("@p_komentatorid", komentatorId);
            var pImie = new NpgsqlParameter("@p_imie", imie);
            var pNazwisko = new NpgsqlParameter("@p_nazwisko", nazwisko);
            var pnickname = new NpgsqlParameter("@p_nickname", nickname);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.edytujkomentatora(@p_komentatorid, @p_imie, @p_nazwisko, @p_nickname)",
                pKomentatorId, pImie, pNazwisko, pnickname
            );
        }
        // 23.Usuń komentatora
        public async Task UsunKomentatoraAsync(int komentatorId)
        {
            var pKomentatorId = new NpgsqlParameter("@p_komentatorid", komentatorId);

            await Database.ExecuteSqlRawAsync(
                "CALL esportleagueoflegends.usunkomentatora(@p_komentatorid)",
                pKomentatorId
            );
        }
        // get_all_tournaments
        public DbSet<GetAllTournamentsResult> GetAllTournamentsResults { get; set; }

        // get_team_players_stats
        public DbSet<GetTeamPlayersStatsResult> GetTeamPlayersStatsResults { get; set; }

        // get_recent_matches_by_commentator
        public DbSet<GetRecentMatchesByCommentatorResult> GetRecentMatchesByCommentatorResults { get; set; }

        // get_teams_by_region
        public DbSet<GetTeamsByRegionResult> GetTeamsByRegionResults { get; set; }

        // get_all_coaches
        public DbSet<GetAllCoachesResult> GetAllCoachesResults { get; set; }

        // get_top_kda_players
        public DbSet<GetTopKdaPlayersResult> GetTopKdaPlayersResults { get; set; }

        // get_most_picked_character
        public DbSet<GetMostPickedCharacterResult> GetMostPickedCharacterResults { get; set; }

        // get_best_team_in_tournament
        public DbSet<GetBestTeamInTournamentResult> GetBestTeamInTournamentResults { get; set; }

        // get_players_with_teams
        public DbSet<GetPlayersWithTeamsResult> GetPlayersWithTeamsResults { get; set; }

        // get_matches_by_tournament
        public DbSet<GetMatchesByTournamentResult> GetMatchesByTournamentResults { get; set; }

        // get_top_winners
        public DbSet<GetTopWinnersResult> GetTopWinnersResults { get; set; }

        // get_teams_with_most_players
        public DbSet<GetTeamsWithMostPlayersResult> GetTeamsWithMostPlayersResults { get; set; }

        // get_tournaments_count_by_region
        public DbSet<GetTournamentsCountByRegionResult> GetTournamentsCountByRegionResults { get; set; }

        // get_coaches_by_region
        public DbSet<GetCoachesByRegionResult> GetCoachesByRegionResults { get; set; }

        // get_match_count_by_commentator
        public DbSet<GetMatchCountByCommentatorResult> GetMatchCountByCommentatorResults { get; set; }

        // get_average_kills_and_deaths_by_player
        public DbSet<GetAverageKillsAndDeathsByPlayerResult> GetAverageKillsAndDeathsByPlayerResults { get; set; }

        // get_top_assisters_by_team
        public DbSet<GetTopAssistersByTeamResult> GetTopAssistersByTeamResults { get; set; }

        // get_commentators_by_region
        public DbSet<GetCommentatorsByRegionResult> GetCommentatorsByRegionResults { get; set; }

        // get_most_picked_characters
        public DbSet<GetMostPickedCharactersResult> GetMostPickedCharactersResults { get; set; }

        // get_teams_with_most_transfers
        public DbSet<GetTeamsWithMostTransfersResult> GetTeamsWithMostTransfersResults { get; set; }
        public object BestTeamInTournament { get; internal set; }

        public DbSet<GetAllTeamsResult> GetAllTeamsResults { get; set; }
        public DbSet<GetAllRegionsResult> GetAllRegionsResults { get; set; }
        public DbSet<GetAllPlayersResult> GetAllPlayersResults { get; set; }
        public DbSet<XYZ> XyzDb { get; set; }
        public DbSet<GetAllMatchesResult> GetAllMatchesResults { get; set; }
        public DbSet<GetAllCharactersResult> GetAllCharactersResults { get; set; }
        public DbSet<GetAllTransfersResult> GetAllTransfersResults { get; set; }
        public DbSet<GetAllCommentatorsResult> GetAllCommentatorsResults { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

        }
        // get_all_tournaments
        public async Task<List<GetAllTournamentsResult>> GetAllTournamentsAsync()
        {
            return await GetAllTournamentsResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_all_tournaments()")
                .ToListAsync();
        }

        // get_team_players_stats
        public async Task<List<GetTeamPlayersStatsResult>> GetTeamPlayersStatsAsync(long teamId)
        {
            return await GetTeamPlayersStatsResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_team_players_stats({0})", teamId)
                .ToListAsync();
        }

        // get_recent_matches_by_commentator
        public async Task<List<GetRecentMatchesByCommentatorResult>> GetRecentMatchesByCommentatorAsync(long commentatorId)
        {
            return await GetRecentMatchesByCommentatorResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_recent_matches_by_commentator({0})", commentatorId)
                .ToListAsync();
        }

        // get_teams_by_region
        public async Task<List<GetTeamsByRegionResult>> GetTeamsByRegionAsync(long regionId)
        {
            return await GetTeamsByRegionResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_teams_by_region({0})", regionId)
                .ToListAsync();
        }

        // get_all_coaches
        public async Task<List<GetAllCoachesResult>> GetAllCoachesAsync()
        {
            return await GetAllCoachesResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_all_coaches()")
                .ToListAsync();
        }

        // get_top_kda_players
        public async Task<List<GetTopKdaPlayersResult>> GetTopKdaPlayersAsync()
        {
            return await GetTopKdaPlayersResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_top_kda_players()")
                .ToListAsync();
        }

        // get_most_picked_character
        public async Task<GetMostPickedCharacterResult> GetMostPickedCharacterAsync()
        {
            return await GetMostPickedCharacterResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_most_picked_character()")
                .FirstOrDefaultAsync();
        }

        // get_best_team_in_tournament
        public async Task<GetBestTeamInTournamentResult> GetBestTeamInTournamentAsync(long turniejId)
        {
            return await GetBestTeamInTournamentResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_best_team_in_tournament({0})", turniejId)
                .FirstOrDefaultAsync();
        }

        // get_players_with_teams
        public async Task<List<GetPlayersWithTeamsResult>> GetPlayersWithTeamsAsync()
        {
            return await GetPlayersWithTeamsResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_players_with_teams()")
                .ToListAsync();
        }

        // get_matches_by_tournament
        public async Task<List<GetMatchesByTournamentResult>> GetMatchesByTournamentAsync(long turniejId)
        {
            return await GetMatchesByTournamentResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_matches_by_tournament({0})", turniejId)
                .ToListAsync();
        }

        // get_top_winners
        public async Task<List<GetTopWinnersResult>> GetTopWinnersAsync()
        {
            return await GetTopWinnersResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_top_winners()")
                .ToListAsync();
        }

        // get_teams_with_most_players
        public async Task<List<GetTeamsWithMostPlayersResult>> GetTeamsWithMostPlayersAsync()
        {
            return await GetTeamsWithMostPlayersResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_teams_with_most_players()")
                .ToListAsync();
        }

        // get_tournaments_count_by_region
        public async Task<List<GetTournamentsCountByRegionResult>> GetTournamentsCountByRegionAsync()
        {
            return await GetTournamentsCountByRegionResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_tournaments_count_by_region()")
                .ToListAsync();
        }

        // get_coaches_by_region
        public async Task<List<GetCoachesByRegionResult>> GetCoachesByRegionAsync(long regionId)
        {
            return await GetCoachesByRegionResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_coaches_by_region({0})", regionId)
                .ToListAsync();
        }

        // get_match_count_by_commentator
        public async Task<List<GetMatchCountByCommentatorResult>> GetMatchCountByCommentatorAsync()
        {
            return await GetMatchCountByCommentatorResults
                .FromSqlRaw("SELECT * FROM esportLeagueOfLegends.get_match_count_by_commentator()")
                .ToListAsync();
        }

        // get_average_kills_and_deaths_by_player
        public async Task<List<GetAverageKillsAndDeathsByPlayerResult>> GetAverageKillsAndDeathsByPlayerAsync()
        {
            return await GetAverageKillsAndDeathsByPlayerResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_average_kills_and_deaths_by_player()")
                .ToListAsync();
        }

        // get_top_assisters_by_team
        public async Task<List<GetTopAssistersByTeamResult>> GetTopAssistersByTeamAsync()
        {
            return await GetTopAssistersByTeamResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_top_assisters_by_team()")
                .ToListAsync();
        }

        // get_commentators_by_region
        public async Task<List<GetCommentatorsByRegionResult>> GetCommentatorsByRegionAsync(long regionId)
        {
            return await GetCommentatorsByRegionResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_commentators_by_region({0})", regionId)
                .ToListAsync();
        }

        // get_most_picked_characters
        public async Task<List<GetMostPickedCharactersResult>> GetMostPickedCharactersAsync()
        {
            return await GetMostPickedCharactersResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_most_picked_characters()")
                .ToListAsync();
        }

        // get_teams_with_most_transfers
        public async Task<List<GetTeamsWithMostTransfersResult>> GetTeamsWithMostTransfersAsync()
        {
            return await GetTeamsWithMostTransfersResults
                .FromSqlRaw("SELECT * FROM EsportLeagueOfLegends.get_teams_with_most_transfers()")
                .ToListAsync();
        }
        public DbSet<GetTeamWinsResult> GetTeamWinsResults { get; set; }

        public async Task<int> GetTeamWinsAsync(int teamId)
        {
            
            var data = await GetTeamWinsResults
                .FromSqlRaw("SELECT esportleagueoflegends.get_team_wins({0}) as \"TeamWins\"", teamId)
                .ToListAsync();

            
            return data.FirstOrDefault()?.TeamWins ?? 0;
        }

        public async Task<List<GetAllTeamsResult>> GetAllTeamsAsync()
        {
            return await GetAllTeamsResults
                .FromSqlRaw("SELECT * FROM esportleagueoflegends.get_all_teams()")
                .ToListAsync();
        }

        public async Task<List<GetAllRegionsResult>> GetAllRegionsAsync()
        {
            return await GetAllRegionsResults
                .FromSqlRaw("SELECT * FROM esportleagueoflegends.get_all_regions()")
                .ToListAsync();
        }

        public async Task<List<GetAllPlayersResult>> GetAllPlayersAsync()
        {
            return await GetAllPlayersResults
                .FromSqlRaw("SELECT * FROM esportleagueoflegends.get_all_players()")
                .ToListAsync();


        }

        public async Task<List<GetAllMatchesResultFront>> GetAllMatchesAsync()
        {
            var result = await GetAllMatchesResults
                .FromSqlRaw("SELECT * FROM esportleagueoflegends.get_all_matches()")
                .ToListAsync();

            var xyz = await XyzDb.FromSqlRaw("SELECT * FROM esportleagueoflegends.xyz")
                .ToListAsync();

            var gracze = await GetAllPlayersAsync();
            var druzyny = await GetAllTeamsAsync();

            var result2 = new List<GetAllMatchesResultFront>();

            foreach (var match in result)
            {
                var xyzRecords = xyz.Where(prp => prp.MeczID == match.MeczID);

                var xyzGraczeIds = xyzRecords.Select(prp => prp.GraczID);

                var gracze2 = gracze.Where(prp => xyzGraczeIds.Contains(prp.GraczID));

                var druzyny2 = druzyny.Where(prp => gracze2.Select(prp => prp.DruzynaID).Distinct().Contains(prp.DruzynaID));

                result2.Add(new()
                {
                    KomentatorID = match.KomentatorID,
                    MeczID = match.MeczID,
                    TurniejID = match.MeczID,
                    DruzynaNames = string.Join(", ", druzyny2.Select(prp => prp.Nazwa)),
                    GraczeNames = string.Join(", ", gracze2.Select(prp => prp.Nickname)),
                });
            }

            return result2;
        }

        public async Task<List<GetAllCharactersResult>> GetAllCharactersAsync()
        {
            return await GetAllCharactersResults
                .FromSqlRaw("SELECT * FROM esportleagueoflegends.get_all_characters()")
                .ToListAsync();
        }

        public async Task<List<GetAllTransfersResultFront>> GetAllTransfersAsync()
        {
            var result = await GetAllTransfersResults
                .FromSqlRaw("SELECT * FROM esportleagueoflegends.get_all_transfers()")
                .ToListAsync();

            var gamers = await GetAllPlayersAsync();

            var wynik = new List<GetAllTransfersResultFront>();
            foreach (var transfer in result)
            {
                var gamer = gamers.FirstOrDefault(prp => prp.GraczID.Equals(transfer.GraczID));
                if (gamer is null)
                    continue;


                wynik.Add(new()
                {
                    GraczID = transfer.GraczID,
                    Druzyna1 = transfer.Druzyna1,
                    Druzyna2 = transfer.Druzyna2,
                    GraczName  = gamer.Nickname,
                    TransferID = transfer.TransferID,
                });
            }

            return wynik;
        }

        public async Task<List<GetAllCommentatorsResult>> GetAllCommentatorsAsync()
        {
            return await GetAllCommentatorsResults
                .FromSqlRaw("SELECT * FROM esportleagueoflegends.get_all_commentators()")
                .ToListAsync();
        }
    }
}
    

