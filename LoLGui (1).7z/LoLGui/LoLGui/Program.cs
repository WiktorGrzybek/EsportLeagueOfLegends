using LoLGui;
using LoLGui.Components;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();




var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");


builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(connectionString));
builder.Services.AddScoped<SelectsService>();
builder.Services.AddScoped<DruzynaService>();
builder.Services.AddScoped<GraczeService>();
builder.Services.AddScoped<MeczService>();
builder.Services.AddScoped<PostacService>();
builder.Services.AddScoped<RegionService>();
builder.Services.AddScoped<TransferService>();
builder.Services.AddScoped<TrenerService>();
builder.Services.AddScoped<TurniejService>();
builder.Services.AddScoped<KomentatorService>();
//builder.Services.AddScoped<XyzService>();

var app = builder.Build();



if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
