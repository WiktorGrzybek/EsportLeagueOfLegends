﻿using System.Threading.Tasks;
using LoLGui;

public class GraczeService
{
    private readonly AppDbContext _db;

    public GraczeService(AppDbContext db)
    {
        _db = db;
    }

    public async Task DodajGracza(string nickname, int druzynaId, string pozycja)
    {
        await _db.DodajGraczaAsync(nickname, druzynaId, pozycja);
    }

    public async Task EdytujGracza(int graczId, string nickname, int druzynaId, string pozycja,
    int przegrane, int wygrane, int eliminacje, int asysty, int zgony)
    {
        await _db.EdytujGraczaAsync(graczId, nickname, druzynaId, pozycja,
            przegrane, wygrane, eliminacje, asysty, zgony);
    }

    public async Task UsunGracza(int graczId)
    {
        await _db.UsunGraczaAsync(graczId);
    }
}