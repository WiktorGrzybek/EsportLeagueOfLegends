﻿using System.Threading.Tasks;
using LoLGui;

public class TransferService
{
    private readonly AppDbContext _db;

    public TransferService(AppDbContext db)
    {
        _db = db;
    }

    public async Task DodajTransfer(int graczId, int druzyna1, int druzyna2)
    {
        await _db.DodajTransferAsync(graczId, druzyna1, druzyna2);
    }

    public async Task EdytujTransfer(int transferId, int graczId, int druzyna1, int druzyna2)
    {
        await _db.EdytujTransferAsync(transferId, graczId, druzyna1, druzyna2);
    }
}