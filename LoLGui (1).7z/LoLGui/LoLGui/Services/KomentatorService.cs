﻿using System.Threading.Tasks;
using LoLGui;

public class KomentatorService
{
    private readonly AppDbContext _db;

    public KomentatorService(AppDbContext db)
    {
        _db = db;
    }

    public async Task DodajKomentatora(string imie, string nazwisko, string nickname)
    {
        await _db.DodajKomentatoraAsync(imie, nazwisko,nickname);
    }

    public async Task EdytujKomentatora(int komentatorId, string imie, string nazwisko, string nickname)
    {
        await _db.EdytujKomentatoraAsync(komentatorId, imie, nazwisko,nickname);
    }

    public async Task UsunKomentatora(int komentatorId)
    {
        await _db.UsunKomentatoraAsync(komentatorId);
    }
}