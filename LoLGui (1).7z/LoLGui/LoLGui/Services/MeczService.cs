﻿using System.Threading.Tasks;
using LoLGui;

public class MeczService
{
    private readonly AppDbContext _db;

    public MeczService(AppDbContext db)
    {
        _db = db;
    }

    public async Task DodajMecz(int komentatorId, int turniejId)
    {
        await _db.DodajMeczAsync(komentatorId, turniejId);
    }

    public async Task EdytujMecz(int meczId, int komentatorId, int turniejId)
    {
        await _db.EdytujMeczAsync(meczId, komentatorId, turniejId);
    }
}