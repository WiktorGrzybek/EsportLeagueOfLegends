﻿using System.Threading.Tasks;
using LoLGui;
using LoLGui.Models;

public class DruzynaService
{
    private readonly AppDbContext _db;

    public DruzynaService(AppDbContext db)
    {
        _db = db;
    }

    public async Task DodajDruzyne(string nazwa, int regionId)
    {
        await _db.DodajDruzyneAsync(nazwa, regionId);
    }

    public async Task EdytujDruzyne(int druzynaId, string nazwa, int regionId)
    {
        await _db.EdytujDruzyneAsync(druzynaId, nazwa, regionId);
    }

    public async Task UsunDruzyne(int druzynaId)
    {
        await _db.UsunDruzyneAsync(druzynaId);
    }

}