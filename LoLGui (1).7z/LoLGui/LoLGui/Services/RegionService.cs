﻿using System.Threading.Tasks;
using LoLGui;
using LoLGui.Models;

public class RegionService
{
    private readonly AppDbContext _db;

    public RegionService(AppDbContext db)
    {
        _db = db;
    }

    public async Task DodajRegion(string nazwa, string skrot)
    {
        await _db.DodajRegionAsync(nazwa, skrot);
    }

    public async Task EdytujRegion(int regionId, string nazwa, string skrot)
    {
        await _db.EdytujRegionAsync(regionId, nazwa, skrot);
    }

    public async Task UsunRegion(int regionId)
    {
        await _db.UsunRegionAsync(regionId);
    }

}