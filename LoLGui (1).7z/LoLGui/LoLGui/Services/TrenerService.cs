﻿using System.Threading.Tasks;
using LoLGui;

public class TrenerService
{
    private readonly AppDbContext _db;

    public TrenerService(AppDbContext db)
    {
        _db = db;
    }

    public async Task DodajTrenera(string imie, string nazwisko, int druzynaId)
    {
        await _db.DodajTreneraAsync(imie, nazwisko, druzynaId);
    }

    public async Task EdytujTrenera(int trenerId, string imie, string nazwisko, int druzynaId)
    {
        await _db.EdytujTreneraAsync(trenerId, imie, nazwisko, druzynaId);
    }

    public async Task UsunTrenera(int trenerId)
    {
        await _db.UsunTreneraAsync(trenerId);
    }
}