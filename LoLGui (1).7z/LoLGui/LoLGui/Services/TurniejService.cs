﻿using System;
using System.Threading.Tasks;
using LoLGui;

public class TurniejService
{
    private readonly AppDbContext _db;

    public TurniejService(AppDbContext db)
    {
        _db = db;
    }

    public async Task DodajTurniej(
        string nazwaTurnieju,
        string rodzaj,
        string organizator,
        string adres,
        int regionId,
        DateTime data
    )
    {
        await _db.DodajTurniejAsync(nazwaTurnieju, rodzaj, organizator, adres, regionId, data);
    }

    public async Task EdytujTurniej(
        int turniejId,
        string nazwaTurnieju,
        string rodzaj,
        string organizator,
        string adres,
        int regionId,
        DateTime data
    )
    {
        await _db.EdytujTurniejAsync(turniejId, nazwaTurnieju, rodzaj, organizator, adres, regionId, data);
    }
}