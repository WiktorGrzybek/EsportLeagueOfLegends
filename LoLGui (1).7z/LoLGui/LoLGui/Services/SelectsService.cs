﻿using System.Collections.Generic;
using System.Threading.Tasks;
using LoLGui.Models;
using LoLGui;
using Npgsql;
using Microsoft.EntityFrameworkCore;

public class SelectsService
{
    public readonly AppDbContext _db;

    public SelectsService(AppDbContext db)
    {
        _db = db;
    }

    // 1) get_all_tournaments
    public async Task<List<GetAllTournamentsResult>> PobierzWszystkieTurnieje()
    {
        return await _db.GetAllTournamentsAsync();
    }

    // 2) get_team_players_stats
    //public async Task<List<GetTeamPlayersStatsResult>> PobierzStatystykiGraczyDruzyny(long teamId)
    //{
    //    return await _db.GetTeamPlayersStatsAsync(teamId);
    //}

    // 3) get_recent_matches_by_commentator
    public async Task<List<GetRecentMatchesByCommentatorResult>> PobierzOstatnieMeczeKomentatora(long commentatorId)
    {
        return await _db.GetRecentMatchesByCommentatorAsync(commentatorId);
    }

    // 4) get_teams_by_region
    public async Task<List<GetTeamsByRegionResult>> PobierzDruzynyZRegionu(long regionId)
    {
        return await _db.GetTeamsByRegionAsync(regionId);
    }

    // 5) get_all_coaches
    public async Task<List<GetAllCoachesResult>> PobierzWszystkichTrenerow()
    {
        return await _db.GetAllCoachesAsync();
    }

    // 6) get_top_kda_players
    public async Task<List<GetTopKdaPlayersResult>> PobierzTopKdaGraczy()
    {
        return await _db.GetTopKdaPlayersAsync();
    }

    // 7) get_most_picked_character
    public async Task<GetMostPickedCharacterResult> PobierzNajczesciejWybieranaPostac()
    {
        return await _db.GetMostPickedCharacterAsync();
    }

    // 8) get_best_team_in_tournament
    public async Task<GetBestTeamInTournamentResult> PobierzNajlepszaDruzyneWTymTurnieju(int turniejId)
    {
        // Ta metoda w kontekście zwraca pojedynczy rekord GetBestTeamInTournamentResult
        return await _db.GetBestTeamInTournamentAsync(turniejId);
    }
    // 9) get_players_with_teams
    public async Task<List<GetPlayersWithTeamsResult>> PobierzGraczyZDruzynami()
    {
        return await _db.GetPlayersWithTeamsAsync();
    }

    // 10) get_matches_by_tournament
    public async Task<List<GetMatchesByTournamentResult>> PobierzMeczeTurnieju(long turniejId)
    {
        return await _db.GetMatchesByTournamentAsync(turniejId);
    }

    // 11) get_top_winners
    public async Task<List<GetTopWinnersResult>> PobierzTopZwyciezcow()
    {
        return await _db.GetTopWinnersAsync();
    }

    // 12) get_teams_with_most_players
    public async Task<List<GetTeamsWithMostPlayersResult>> PobierzDruzynyZNajwiekszaLiczbaGraczy()
    {
        return await _db.GetTeamsWithMostPlayersAsync();
    }

    // 13) get_tournaments_count_by_region
    public async Task<List<GetTournamentsCountByRegionResult>> PobierzLiczbeTurniejowWRegionach()
    {
        return await _db.GetTournamentsCountByRegionAsync();
    }

    // 14) get_coaches_by_region
    public async Task<List<GetCoachesByRegionResult>> PobierzTrenerowZRegionu(long regionId)
    {
        return await _db.GetCoachesByRegionAsync(regionId);
    }

    // 15) get_match_count_by_commentator
    public async Task<List<GetMatchCountByCommentatorResult>> PobierzLiczbeMeczowKomentatora()
    {
        return await _db.GetMatchCountByCommentatorAsync();
    }

    // 17) get_average_kills_and_deaths_by_player
    public async Task<List<GetAverageKillsAndDeathsByPlayerResult>> PobierzSrednieZabojstwaZgonyGraczy()
    {
        return await _db.GetAverageKillsAndDeathsByPlayerAsync();
    }

    // 18) get_top_assisters_by_team
    public async Task<List<GetTopAssistersByTeamResult>> PobierzTopAsystentowZDruzyny()
    {
        return await _db.GetTopAssistersByTeamAsync();
    }

    // 19) get_commentators_by_region
    public async Task<List<GetCommentatorsByRegionResult>> PobierzKomentatorowZRegionu(long regionId)
    {
        return await _db.GetCommentatorsByRegionAsync(regionId);
    }

    // 20) get_most_picked_characters
    public async Task<List<GetMostPickedCharactersResult>> PobierzNajczesciejWybieranePostacie()
    {
        return await _db.GetMostPickedCharactersAsync();
    }

    // 21) get_teams_with_most_transfers
    public async Task<List<GetTeamsWithMostTransfersResult>> PobierzDruzynyZNajwiekszaLiczbaTransferow()
    {
        return await _db.GetTeamsWithMostTransfersAsync();
    }
    //// 21) get_team_wins
    //public async Task<int> PobierzTeamWins(int teamId)
    //{
    //    return await _db.GetTeamWinsAsync(teamId);
    //}

    public async Task<List<GetAllTeamsResult>> PobierzWszystkieDruzyny()
    {
        return await _db.GetAllTeamsAsync();
    }

    public async Task<List<GetAllRegionsResult>> PobierzWszystkieRegiony()
    {
        return await _db.GetAllRegionsAsync();
    }

    public async Task<List<GetAllPlayersResult>> PobierzWszystkichGraczy()
    {
        return await _db.GetAllPlayersAsync();
    }

    public async Task<List<GetAllMatchesResultFront>> PobierzWszystkieMecze()
    {
        return await _db.GetAllMatchesAsync();
    }

    public async Task<List<GetAllCharactersResult>> PobierzWszystkiePostacie()
    {
        return await _db.GetAllCharactersAsync();
    }

    public async Task<List<GetAllTransfersResultFront>> PobierzWszystkieTransfery()
    {
        return await _db.GetAllTransfersAsync();
    }

    public async Task<List<GetAllCommentatorsResult>> PobierzWszystkichKomentatorow()
    {
        return await _db.GetAllCommentatorsAsync();
    }
}
