﻿//using System.Threading.Tasks;
//using LoLGui;

//public class XyzService
//{
//    private readonly AppDbContext _db;

//    public XyzService(AppDbContext db)
//    {
//        _db = db;
//    }

//    public async Task DodajXyz(int graczId, int meczId, int postacId, int wynik)
//    {
//        await _db.DodajXyzAsync(graczId, meczId, postacId, wynik);
//    }

//    public async Task EdytujXyz(int uniqueId, int graczId, int meczId, int postacId, int wynik)
//    {
//        await _db.EdytujXyzAsync(uniqueId, graczId, meczId, postacId, wynik);
//    }
//}