﻿using System.Threading.Tasks;
using LoLGui;

public class PostacService
{
    private readonly AppDbContext _db;

    public PostacService(AppDbContext db)
    {
        _db = db;
    }

    public async Task DodajPostac(string nazwa)
    {
        await _db.DodajPostacAsync(nazwa);
    }

    public async Task EdytujPostac(int postacId, string nazwa)
    {
        await _db.EdytujPostacAsync(postacId, nazwa);
    }
}